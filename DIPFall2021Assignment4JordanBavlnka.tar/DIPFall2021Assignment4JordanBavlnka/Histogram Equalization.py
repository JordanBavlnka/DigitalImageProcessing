#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cv2
import matplotlib.pyplot as plt 

#read imput image
img = cv2.imread("image.jpg", cv2.IMREAD_COLOR)

#calculate the histogram of image
color = ('b','g','r')
for i,col in enumerate(color):
    histr = cv2.calcHist([img],[i],None,[32],[0,256])
    plt.plot(histr,color = col)
    plt.xlim([0,32])

#display the image
cv2.imshow("test", img)

plt.show()

cv2.waitKey(0)


# In[2]:


import cv2
import matplotlib.pyplot as plt 

#read imput image
img = cv2.imread("image.jpg", cv2.IMREAD_COLOR)

#calculate the histogram of image
color = ('b','g','r')
for i,col in enumerate(color):
    histr = cv2.calcHist([img],[i],None,[256],[0,256])
    plt.plot(histr,color = col)
    plt.xlim([0,256])

#display the image
cv2.imshow("test", img)

plt.show()

cv2.waitKey(0)


# In[3]:


import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt

img = cv.imread('image.jpg',0)
plt.hist(img.ravel(),256,[0,256]); plt.show()


# In[4]:


import cv2
import numpy as np
import matplotlib.pyplot as plt
   
# Read an image
image = cv2.imread('image.jpg')
   
# Apply log transformation method
c = 255 / np.log(1 + np.max(image))
log_image = c * (np.log(image + 1))
   
# Specify the data type so that
# float value will be converted to int
log_image = np.array(log_image, dtype = np.uint8)
   
# Display both images
plt.imshow(image)
plt.show()
plt.imshow(log_image)
plt.show()

cv2.waitKey()


# In[5]:


from PIL import Image
import cv2
import matplotlib.pyplot as plt
import numpy as np

IN_FILE = "graysnow-sm.jpg"
OUT_FILE = "result.jpg"

def make_histogram(img):
    histogram = np.zeros(256, dtype=int)
    for i in range(img.size):
        histogram[img[i]] += 1
    return histogram

def make_cumsum(histogram):
    """ Create an array that represents the cumulative sum of the histogram """
    cumsum = np.zeros(256, dtype=int)
    cumsum[0] = histogram[0]
    for i in range(1, histogram.size):
        cumsum[i] = cumsum[i-1] + histogram[i]
    return cumsum

def make_mapping(cumsum):
    """ Create a mapping s.t. each old colour value is mapped to a new
        one between 0 and 255 """
    mapping = np.zeros(256, dtype=int)
    grey_levels = 256
    for i in range(grey_levels):
        mapping[i] = max(0, round((grey_levels*cumsum[i])/(IMG_H*IMG_W))-1)
    return mapping

def apply_mapping(img, mapping):
    """ Apply the mapping to our image """
    new_image = np.zeros(img.size, dtype=int)
    for i in range(img.size):
        new_image[i] = mapping[img[i]]
    return new_image

# Load image, store width and height into constants
pillow_img = Image.open(IN_FILE)
IMG_W, IMG_H = pillow_img.size

# Read in and flatten our greyscale image, calculate the histogram,
# cumulative sum, mapping and then apply the mapping to create a new image
img = np.array(pillow_img).flatten()
histogram = make_histogram(img)
cumsum = make_cumsum(histogram)
mapping = make_mapping(cumsum)
new_image = apply_mapping(img, mapping)

# Save the image
output_image = Image.fromarray(np.uint8(new_image.reshape((IMG_H, IMG_W))))
output_image.save(OUT_FILE)

# Display the old (blue) and new (orange) histograms next to eachother
x_axis = np.arange(256)
fig = plt.figure()
fig.add_subplot(1, 2, 1)
plt.bar(x_axis, histogram)
fig.add_subplot(1, 2, 2)
plt.bar(x_axis, make_histogram(new_image), color="orange")
plt.show()


# In[ ]:




